"""Вся игровая логика. Баланс (цены, доходы) меняется здесь."""
from datetime import timedelta
from .db import User, Building, Ledger, now

STORE_HOURS = 8  # сколько часов копится доход в здании

# name, emoji, размер в клетках, цена, доход/час, нужный уровень
BUILDINGS = {
    "road":     dict(name="Дорога",        e="🟫", w=1, h=1, cost=10,    income=0,   lvl=1),
    "tree":     dict(name="Дерево",        e="🌳", w=1, h=1, cost=50,    income=0,   lvl=1),
    "fence":    dict(name="Забор",         e="🧱", w=1, h=1, cost=20,    income=0,   lvl=1),
    "fountain": dict(name="Фонтан",        e="⛲", w=1, h=1, cost=150,   income=0,   lvl=2),
    "house":    dict(name="Дом",           e="🏠", w=2, h=2, cost=300,   income=8,   lvl=1),
    "tea":      dict(name="Чайхана",       e="🍵", w=2, h=2, cost=500,   income=50,  lvl=1),
    "bazaar":   dict(name="Базар",         e="🏪", w=3, h=2, cost=2500,  income=100, lvl=3),
    "caravan":  dict(name="Караван-сарай", e="🐪", w=3, h=3, cost=8000,  income=150, lvl=5),
    "palace":   dict(name="Дворец",        e="🕌", w=4, h=4, cost=30000, income=300, lvl=8),
}


class GameError(Exception):
    pass


def level_of(xp):
    return 1 + int((xp / 50) ** 0.5)


def change(db, u, currency, amount, reason):
    """Единственное место, где меняются золото и алмазы. Пишет в историю."""
    new = getattr(u, currency) + amount
    if new < 0:
        raise GameError("Не хватает золота" if currency == "gold" else "Не хватает алмазов")
    setattr(u, currency, new)
    db.add(Ledger(user_id=u.id, currency=currency, amount=amount, balance_after=new, reason=reason))


def stored(b):
    hours = min((now() - b.last_collected).total_seconds() / 3600, STORE_HOURS)
    return int(hours * BUILDINGS[b.type]["income"])


def build(db, u, t, x, y):
    c = BUILDINGS.get(t)
    if not c:
        raise GameError("Нет такого здания")
    if level_of(u.xp) < c["lvl"]:
        raise GameError(f"Нужен уровень {c['lvl']}")
    if x < 0 or y < 0 or x + c["w"] > u.land_size or y + c["h"] > u.land_size:
        raise GameError("Это за границей участка")
    for b in db.query(Building).filter_by(user_id=u.id):
        o = BUILDINGS[b.type]
        if x < b.x + o["w"] and b.x < x + c["w"] and y < b.y + o["h"] and b.y < y + c["h"]:
            raise GameError("Место занято")
    change(db, u, "gold", -c["cost"], f"build:{t}")
    db.add(Building(user_id=u.id, type=t, x=x, y=y, last_collected=now()))
    u.xp += max(1, c["cost"] // 20)


def collect(db, u):
    total = 0
    for b in db.query(Building).filter_by(user_id=u.id):
        if BUILDINGS[b.type]["income"] > 0:
            total += stored(b)
            b.last_collected = now()
    if total:
        change(db, u, "gold", total, "collect")
    return total


def expand_cost(u):
    n = (u.land_size - 12) // 2
    return (10, 0) if n == 0 else (5, 10000 * n)  # (алмазы, золото)


def expand(db, u):
    if u.land_size >= 40:
        raise GameError("Максимальный размер участка")
    gems, gold = expand_cost(u)
    change(db, u, "gems", -gems, "expand")
    if gold:
        change(db, u, "gold", -gold, "expand")
    u.land_size += 2


def daily(db, u):
    if u.last_daily and u.last_daily.date() == now().date():
        raise GameError("Награда за сегодня уже получена")
    change(db, u, "gold", 300, "daily")
    change(db, u, "gems", 1, "daily")
    u.last_daily = now()


def state(db, u):
    gems, gold = expand_cost(u)
    return {
        "user": {"gold": u.gold, "gems": u.gems, "xp": u.xp, "level": level_of(u.xp), "land": u.land_size},
        "buildings": [
            {"id": b.id, "type": b.type, "x": b.x, "y": b.y, "stored": stored(b)}
            for b in db.query(Building).filter_by(user_id=u.id)
        ],
        "catalog": BUILDINGS,
        "expand": {"gems": gems, "gold": gold},
        "daily_ready": not (u.last_daily and u.last_daily.date() == now().date()),
        "next_xp": 50 * level_of(u.xp) ** 2,
    }
