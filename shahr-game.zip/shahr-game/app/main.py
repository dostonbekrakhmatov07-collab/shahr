import asyncio
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Depends, Header, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session
from . import game
from .auth import verify_init_data
from .config import BOT_TOKEN
from .db import Base, engine, SessionLocal, User, Building, now

BASE = Path(__file__).resolve().parent.parent


@asynccontextmanager
async def lifespan(app):
    Base.metadata.create_all(engine)
    task = None
    if BOT_TOKEN:
        from .bot import run_bot
        task = asyncio.create_task(run_bot())
    yield
    if task:
        task.cancel()


app = FastAPI(lifespan=lifespan)


@app.exception_handler(game.GameError)
async def game_error(request, exc):
    return JSONResponse({"detail": str(exc)}, status_code=400)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def current_user(x_init_data: str = Header(default=""), db: Session = Depends(get_db)) -> User:
    try:
        tg = verify_init_data(x_init_data)
    except (ValueError, KeyError):
        raise HTTPException(401, "Откройте игру через Telegram")
    u = db.query(User).filter(User.id == tg["id"]).with_for_update().first()
    if not u:
        u = User(id=tg["id"], username=tg.get("username"))
        db.add(u)
        db.flush()
        game.change(db, u, "gold", 5000, "start")
        game.change(db, u, "gems", 10, "start")
        db.add(Building(user_id=u.id, type="tea", x=5, y=5, last_collected=now()))
        db.commit()
    if u.banned:
        raise HTTPException(403, "Аккаунт заблокирован")
    return u


class BuildIn(BaseModel):
    type: str
    x: int
    y: int


class RemoveIn(BaseModel):
    id: int


@app.get("/api/state")
def api_state(u: User = Depends(current_user), db: Session = Depends(get_db)):
    return game.state(db, u)


@app.post("/api/build")
def api_build(p: BuildIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    game.build(db, u, p.type, p.x, p.y)
    db.commit()
    return game.state(db, u)


@app.post("/api/remove")
def api_remove(p: RemoveIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    b = db.query(Building).filter_by(id=p.id, user_id=u.id).first()
    if not b:
        raise game.GameError("Здание не найдено")
    db.delete(b)
    db.commit()
    return game.state(db, u)


@app.post("/api/collect")
def api_collect(u: User = Depends(current_user), db: Session = Depends(get_db)):
    game.collect(db, u)
    db.commit()
    return game.state(db, u)


@app.post("/api/expand")
def api_expand(u: User = Depends(current_user), db: Session = Depends(get_db)):
    game.expand(db, u)
    db.commit()
    return game.state(db, u)


@app.post("/api/daily")
def api_daily(u: User = Depends(current_user), db: Session = Depends(get_db)):
    game.daily(db, u)
    db.commit()
    return game.state(db, u)


@app.get("/")
def index():
    return FileResponse(BASE / "static" / "index.html")
