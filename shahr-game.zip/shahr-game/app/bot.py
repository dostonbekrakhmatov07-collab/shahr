from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from sqlalchemy import func
from .config import BOT_TOKEN, ADMIN_ID, WEBAPP_URL
from .db import SessionLocal, User, Building, Ledger
from .game import change, GameError

dp = Dispatcher()


def is_admin(m: Message) -> bool:
    return bool(ADMIN_ID) and m.from_user is not None and m.from_user.id == ADMIN_ID


@dp.message(Command("start"))
async def start(m: Message):
    kb = None
    if WEBAPP_URL:
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🏙 Играть", web_app=WebAppInfo(url=WEBAPP_URL))]])
    await m.answer("Добро пожаловать, правитель! Построй свой город.", reply_markup=kb)


@dp.message(Command("give"))
async def give(m: Message):
    if not is_admin(m):
        return
    p = (m.text or "").split()
    if len(p) < 4 or p[2] not in ("gold", "gems"):
        return await m.answer("Формат: /give ID gold|gems число")
    try:
        uid, amt = int(p[1]), int(p[3])
    except ValueError:
        return await m.answer("ID и число должны быть целыми")
    with SessionLocal() as db:
        u = db.get(User, uid)
        if not u:
            return await m.answer("Игрок не найден")
        try:
            change(db, u, p[2], amt, "admin")
            db.commit()
        except GameError as e:
            return await m.answer(str(e))
        await m.answer(f"Готово. Золото: {u.gold}, алмазы: {u.gems}")


@dp.message(Command("user"))
async def user(m: Message):
    if not is_admin(m):
        return
    p = (m.text or "").split()
    if len(p) < 2 or not p[1].isdigit():
        return await m.answer("Формат: /user ID")
    with SessionLocal() as db:
        u = db.get(User, int(p[1]))
        if not u:
            return await m.answer("Игрок не найден")
        rows = db.query(Ledger).filter_by(user_id=u.id).order_by(Ledger.id.desc()).limit(8).all()
        log = "\n".join(f"{r.currency} {r.amount:+d} ({r.reason})" for r in rows)
        await m.answer(f"@{u.username} | золото {u.gold} | алмазы {u.gems} | опыт {u.xp} | участок {u.land_size}\n\n{log}")


@dp.message(Command("stats"))
async def stats(m: Message):
    if not is_admin(m):
        return
    with SessionLocal() as db:
        n = db.query(func.count(User.id)).scalar()
        b = db.query(func.count(Building.id)).scalar()
    await m.answer(f"Игроков: {n}\nЗданий: {b}")


async def run_bot():
    bot = Bot(BOT_TOKEN)
    await dp.start_polling(bot, handle_signals=False)
