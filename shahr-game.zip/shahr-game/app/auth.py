import hashlib, hmac, json, time
from urllib.parse import parse_qsl
from .config import BOT_TOKEN, DEV_MODE


def verify_init_data(init_data: str) -> dict:
    """Проверяет подпись Telegram. Возвращает данные пользователя или ValueError."""
    if DEV_MODE and init_data.startswith("dev:"):
        return {"id": int(init_data[4:]), "username": "dev"}
    try:
        data = dict(parse_qsl(init_data, keep_blank_values=True))
        got = data.pop("hash")
    except KeyError:
        raise ValueError("bad init data")
    check = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    calc = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc, got):
        raise ValueError("bad signature")
    if time.time() - int(data.get("auth_date", 0)) > 86400:
        raise ValueError("expired")
    return json.loads(data["user"])
